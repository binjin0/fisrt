package dte;

public class Serializable {

}
