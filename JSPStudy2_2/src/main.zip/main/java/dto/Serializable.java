package dto;

public interface Serializable {

}